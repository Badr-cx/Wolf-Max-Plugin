#!/system/bin/sh
SOURCE="/mnt/sda1/Max-Audio.cfg"
DEST="/data/plugin/WolfAudio/audio_list.m3u"

if [ -f "$SOURCE" ]; then
    cp "$SOURCE" "$DEST"
    chmod 644 "$DEST"
    # تحديث واجهة الجهاز
    am broadcast -a com.icone.plugin.ACTION_UPDATE_AUDIO
fi